const BannerIcon = () => {
    return (
        <div className="flex justify-evenly">
            <div>
                aaa
            </div>
            <div>
                bbb
            </div>
            <div>
                ccc
            </div>
        </div>
     );
}
 
export default BannerIcon;