
export type TLoading = "idle" | "pending" | "succeeded" | "failed";
