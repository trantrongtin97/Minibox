function Register() {
    return ( <div>Register</div> );
}

export default Register;