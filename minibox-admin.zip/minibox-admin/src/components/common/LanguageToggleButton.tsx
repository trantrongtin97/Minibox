import { useTranslation } from "react-i18next";
import { useState } from "react";
import { Dropdown } from "@components/ui/dropdown/Dropdown";
import { DropdownItem } from "@components/ui/dropdown/DropdownItem";
import { en, vn } from "@assets/Images/country-icons/index";

interface Language {
  code: string;
  name: string;
}

const LanguageToggleButton = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { i18n } = useTranslation();
  const [selectLanguage, setSelectLanguage] = useState(i18n.language);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const closeDropdown = () => {
    setIsOpen(false);
    console.log(i18n.language);
  };

  const hanlderSelectedLanguage = (key: string | "vi") => {
    setSelectLanguage(key);
    i18n.changeLanguage(key);
    closeDropdown();
  };

  const getLanguage = (key: string) => {
    return supportLanguage.find((l) => l.code === key);
  };

  const supportLanguage = [
    { code: "en", name: "English", img: en },
    { code: "vi", name: "Viet Nam", img: vn },
  ];

  const objLang = getLanguage(selectLanguage);

  return (
    <div className="relative">
      <button
        onClick={toggleDropdown}
        className="flex items-center justify-center text-gray-500 transition-colors bg-white border border-gray-200 rounded-full dropdown-toggle hover:text-gray-700 h-11 w-11 hover:bg-gray-100 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
      >
        <img className="size-8" src={objLang?.img} alt={objLang?.code} />
      </button>

      <Dropdown
        onClose={closeDropdown}
        isOpen={isOpen}
        className="absolute right-0 mt-[24px] flex w-[260px] flex-col rounded-2xl border border-gray-200 bg-white p-3 shadow-theme-lg dark:border-gray-800 dark:bg-gray-900"
      >
        <ul className="flex flex-col gap-1 pt-4 pb-3 border-b border-gray-200 dark:border-gray-800 max-h-[350px] overflow-y-scroll custom-scrollbar">
          {supportLanguage.map((language: Language) => {
            return (
              <li key={language.code}>
                <DropdownItem
                  onItemClick={() => hanlderSelectedLanguage(language.code)}
                  tag="button"
                  className={`rounded-lg border-gray-100 hover:bg-gray-100 dark:border-gray-800 dark:hover:bg-white/5 ${
                    selectLanguage === language.code ? "menu-item-active" : ""
                  }`}
                >
                  <span className="font-medium dark:text-gray-400 ">
                    {language.name}
                  </span>
                </DropdownItem>
              </li>
            );
          })}
        </ul>
      </Dropdown>
    </div>
  );
};

export default LanguageToggleButton;
