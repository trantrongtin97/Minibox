import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChevronRight,
  faChevronLeft,
} from "@fortawesome/free-solid-svg-icons";
interface TablePagination {
  totalItems: number;
  itemsPerPage: number;
  currentPage: number;
  setCurrentPage: Function;
}

const Pagination = ({
  totalItems,
  itemsPerPage,
  currentPage,
  setCurrentPage,
}: TablePagination) => {
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  const pages = [];
  for (let i = 1; i <= totalPages; i++) {
    pages.push(i);
  }

  const handlePrevious = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <div className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6  dark:border-white/[0.05] dark:bg-white/[0.03]">
      <div className="flex flex-1 justify-between sm:hidden">
        <button
          onClick={handlePrevious}
          disabled={currentPage === 1}
          className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:text-gray-400  dark:bg-white/[0.03]"
        >
          Previous
        </button>
        <a
          href="#"
          className="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:text-gray-400  dark:bg-white/[0.03]"
        >
          Next
        </a>
      </div>
      <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between ">
        <div>
          <div className="text-sm text-gray-700 flex gap-1 dark:text-gray-400">
            <span>Showing</span>
            <span className="font-medium">{itemsPerPage}</span>
            <span>of</span>
            <span className="font-medium">{totalItems}</span>
            <span>results</span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <nav
            className="isolate inline-flex -space-x-px rounded-md shadow-xs"
            aria-label="Pagination"
          >
            <button
              onClick={handlePrevious}
              disabled={currentPage === 1}
              className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-gray-300 ring-inset hover:bg-gray-50 focus:z-20 focus:outline-offset-0 dark:text-gray-400  dark:bg-white/[0.03]"
            >
              <span className="sr-only">Previous</span>
              <FontAwesomeIcon className="size-5" icon={faChevronLeft} />
            </button>
            {pages.map((page) => {
              if (page > 3 && page < totalPages - 3) {
                if (page === 4) {
                  return (
                    <span
                      key={page}
                      className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-700 ring-1 ring-gray-300 ring-inset focus:outline-offset-0  dark:text-gray-400  dark:bg-white/[0.03]"
                    >
                      ...
                    </span>
                  );
                } else {
                  return;
                }
              } else {
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`${
                      page === currentPage
                        ? "relative inline-flex items-center px-4 py-2 text-sm font-medium  bg-indigo-600 text-white dark:bg-brand-500/[0.12] dark:text-brand-400"
                        : "relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-gray-300 ring-inset hover:bg-gray-100 focus:z-20 focus:outline-offset-0 dark:hover:bg-gray-400/[0.5]  dark:text-gray-400"
                    }`}
                    aria-current={page === currentPage ? "page" : undefined}
                  >
                    {page}
                  </button>
                );
              }
            })}

            <button
              onClick={handleNext}
              disabled={currentPage === totalPages}
              className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-gray-300 ring-inset focus:z-20 focus:outline-offset-0  dark:text-gray-400"
            >
              <span className="sr-only">Next</span>
              <FontAwesomeIcon className="size-5" icon={faChevronRight} />
            </button>
          </nav>
        </div>
      </div>
    </div>
  );
};

export default Pagination;
