import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
  Pagination,
} from "@components/ui/table";
import Badge from "@components/ui/badge/Badge";
import { githubLight } from "@assets/Images";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPen, faEye } from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";

interface Customer {
  id: number;
  name: string;
  email: string;
  image: string;
  location: string;
  status: string;
  spent: number;
}

const tableData: Customer[] = [
  {
    id: 1,
    name: "3T",
    email:
      "trantrongtin97@gmail.comfhagfkasfhsadfkjsgfdfghaskdjfghasdkjfsghadfkjsghdafkjasghdfakjsfdfghaskdjfghasdkjfsghadfkjsghdafkjasghdfakjskjasghdfakjsfdfghaskdjfghasdkjfsghadfkjsghdafkjasghdfakjsfdfghaskdjfghasdkjfsghadfkjsghdafkjasghdfakjsfkjsghdafkjasghdfakjsfdfghaskdjfghasdkjfsghadfkjsghdafkjasghdfakjsfdfghaskdjfghasdkjfsghadfkjsghdafkjasghdfakjskjfsghadfkjsghdafkjasghdfakjsfghaskdjfghaskfjghasdfkjghasdfkjasghfkajghfakjhfgjkdfgh",
    image: githubLight,
    location: "HCM, VN",
    status: "Active",
    spent: 4367.15,
  },
  {
    id: 2,
    name: "4T",
    email: "trantrongtin9777@gmail.com",
    image: githubLight,
    location:
      "HCM, VNnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn",
    status: "Pending",
    spent: 4312.15555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555,
  },
  {
    id: 3,
    name: "5T",
    email: "trantrongtin9767@gmail.com",
    image: githubLight,
    location: "HCM, VN",
    status: "Error",
    spent: 4312.15,
  },
];

export default function BasicTable() {
  const totalItems: number = 97;
  const itemsPerPage: number = 10;
  const [currentPage, setCurrentPage] = useState(1);
  const hanldeSetCurrentPage = (numPage: number) => {
    setCurrentPage(numPage);
  };

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
      <div className="max-w-full overflow-x-auto ">
        <div className="min-w-[1102px]">
          <Table>
            {/* Table Header */}
            <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
              <TableRow>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-extrabold text-gray-500 text-start text-theme-sm dark:text-gray-400"
                >
                  User
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-extrabold text-gray-500 text-start text-theme-sm dark:text-gray-400"
                >
                  Email
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-extrabold text-gray-500 text-start text-theme-sm dark:text-gray-400"
                >
                  Location
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-extrabold text-gray-500 text-start text-theme-sm dark:text-gray-400"
                >
                  Status
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-extrabold text-gray-500 text-start text-theme-sm dark:text-gray-400"
                >
                  Budget
                </TableCell>
              </TableRow>
            </TableHeader>

            {/* Table Body */}
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {tableData.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="px-5 py-4 sm:px-6 text-start">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 overflow-hidden rounded-full">
                        <img
                          width={40}
                          height={40}
                          src={order.image}
                          alt={order.name}
                        />
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="break-all px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {order.email}
                  </TableCell>
                  <TableCell className="break-all px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {order.location}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    <Badge
                      size="sm"
                      color={
                        order.status === "Active"
                          ? "success"
                          : order.status === "Pending"
                          ? "warning"
                          : "error"
                      }
                    >
                      {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="break-all px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {order.spent}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <Pagination
          totalItems={totalItems}
          itemsPerPage={itemsPerPage}
          currentPage={currentPage}
          setCurrentPage={hanldeSetCurrentPage}
        />
      </div>
    </div>
  );
}
