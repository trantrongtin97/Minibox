import BasicTable from "@components/tables/basic/BasicTable";
import PageMeta from "@components/common/PageMeta";
import PageBreadcrumb from "@components/common/PageBreadCrumb";
import ComponentCard from "@components/common/ComponentCard";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass, faFilter } from "@fortawesome/free-solid-svg-icons";
import Input from "@components/form/input/InputField";
import Button from "@components/ui/button/Button";

const Dashboard = () => {
  return (
    <>
      <PageMeta
        title="Minibox Dashboard"
        description="This is Minibpx Ecommerce Dashboard"
      />
      <PageBreadcrumb pageTitle="Dashboard" />
      <div className="space-y-6">
        <ComponentCard title="Basic Table">
          <div className=" dark:border-gray-800">
            <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-10 py-1 gap-2">
              <div className="col-span-3 md:col-span-5 lg:col-span-9 relative">
                <Input type="text" placeholder="Search something...." />
                <button className="absolute z-30 -translate-y-1/2 cursor-pointer right-4 top-1/2">
                  <FontAwesomeIcon
                    className="fill-gray-500 dark:fill-gray-400 size-5 dark:text-gray-400"
                    icon={faMagnifyingGlass}
                  />
                </button>
              </div>
              <div>
                <div className="flex items-center">
                  <Button
                    size="sm"
                    variant="outline"
                    startIcon={
                      <FontAwesomeIcon className="size-5" icon={faFilter} />
                    }
                    className="w-full"
                  >
                    Filter
                  </Button>
                </div>
              </div>
            </div>
            <BasicTable />
          </div>
        </ComponentCard>
      </div>
    </>
  );
};

export default Dashboard;
