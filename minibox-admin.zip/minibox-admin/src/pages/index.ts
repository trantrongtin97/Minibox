import Dashboard from "./Dashboard/dashboard";
import Error from "./OrtherPage/error";
import SignIn from "./AuthPages/SignIn";

export { Dashboard, Error, SignIn };
