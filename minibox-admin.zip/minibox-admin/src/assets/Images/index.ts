import githubLight from "@assets/Images/github-light.png";
import githubDark from "@assets/Images/github-dark.png";
import page404 from "@assets/Images/404.jpg";

export { githubLight, githubDark, page404 };
