import china from "@assets/Images/country-icons/china.png";
import german from "@assets/Images/country-icons/german.png";
import italy from "@assets/Images/country-icons/italy.png";
import japan from "@assets/Images/country-icons/japan.png";
import ko from "@assets/Images/country-icons/ko.png";
import laos from "@assets/Images/country-icons/laos.png";
import spain from "@assets/Images/country-icons/spain.png";
import en from "@assets/Images/country-icons/uk.png";
import vn from "@assets/Images/country-icons/vietnam.png";
import thai from "@assets/Images/country-icons/thai.png";

export { china, german, italy, japan, ko, laos, spain, en, vn, thai };
