import i18next from "i18next";
import ChainedBackend from "i18next-chained-backend";
import { initReactI18next } from "react-i18next";
import HttpBackEnd from "i18next-http-backend";
import LocalStorageBackend from "i18next-localstorage-backend";

i18next
  .use(initReactI18next)
  .use(ChainedBackend)
  .init({
    debug: true,
    lng: "vi",
    fallbackLng: "vi",
    interpolation: {
      escapeValue: false,
    },
    backend: {
      backends: [LocalStorageBackend, HttpBackEnd],

      backendOptions: [
        {
          expirationTime: 7 * 24 * 60 * 60 * 1000, // 7 days
        },
        {
          loadPath: "http://localhost:3005/locales/{{lng}}/{{ns}}.json",
        },
      ],
    },
  });

export default i18next;

/*backend: {
  projectId: '[PROJECT_ID]',
  apiKey: '[API_KEY]',
  referenceLng: '[LNG]'
}*/
