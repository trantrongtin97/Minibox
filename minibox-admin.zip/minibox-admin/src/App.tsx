import { Provider } from "react-redux";
import { BrowserRouter as Router, Routes, Route } from "react-router";
import store from "@stores/index";
import { ThemeProvider } from "@contexts/ThemeContext.tsx";
import { AppWrapper } from "@components/common/PageMeta.tsx";
import DefaultLayout from "@layouts/DefaultLayout";
import { Dashboard, SignIn } from "@pages/index";
import BasicTable from "@components/tables/basic/BasicTable";
import NotFound from "@components/orther-pages/NotFound";

function App() {
  return (
    <ThemeProvider>
      <AppWrapper>
        <Provider store={store}>
          <Router>
            <Routes>
              {/* Dashboard Layout */}
              <Route element={<DefaultLayout />}>
                <Route index path="/" element={<Dashboard />} />

                {/* Tables */}
                <Route path="/basic-tables" element={<BasicTable />} />
              </Route>

              {/* Auth Layout */}
              <Route path="/login" element={<SignIn />} />

              {/* Fallback Route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Router>
        </Provider>
      </AppWrapper>
    </ThemeProvider>
  );
}

export default App;
