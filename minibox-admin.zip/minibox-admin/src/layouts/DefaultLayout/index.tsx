import { SidebarProvider } from "@contexts/SidebarContext";
import LayoutContent from "@layouts/DefaultLayout/LayoutContent";

const DefaultLayout = () => {
  return (
    <SidebarProvider>
      <LayoutContent />
    </SidebarProvider>
  );
};

export default DefaultLayout;
